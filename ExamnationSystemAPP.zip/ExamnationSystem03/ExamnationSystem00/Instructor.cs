﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ExamnationSystem00.Models;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using static System.Net.Mime.MediaTypeNames;

namespace ExamnationSystem00
{
    public partial class Instructor : Form
    {
        ExamDB ExamSys = new ExamDB();
        public int id;
        public string name;
        public Instructor(int _id, string _name)
        {
            InitializeComponent();
            pictureBox2.Visible = true;
            addtopicbtn.Visible = false;
            crs_id_addcrs_lable.Visible = false;
            crs_name_addcrs_lable.Visible = false;
            topbame_txt.Visible = false;
            TopName_lab.Visible = false;



            crsname_txt.Visible = false;
            crsidaddcourse_txt.Visible = false;
            addcrsbtndet.Visible = false;
            crsHours_lab.Visible = false;
            crshours_txt.Visible = false;

            dataGridView1.Visible = false;

            id_label.Visible = false;
            Name_Label.Visible = false;
            Salary_lable.Visible = false;
            dob_lable.Visible = false;
            Ciy_Lable.Visible = false;
            Phone_Lable.Visible = false;
            email_lable.Visible = false;
            Gender_label.Visible = false;
            id = _id;
            name = _name;
            Instructors I = ExamSys.Instructors.FirstOrDefault(x => x.InsId == id);
            label1.Text = "Hello " + _name + "!";
        }

        private void Instructor_Load(object sender, EventArgs e)
        {

        }

        private void AddCoursebtn_Click(object sender, EventArgs e)
        {
            pictureBox2.Visible = false;
            topbame_txt.Visible = false;
            TopName_lab.Visible = false;
            dataGridView1.Visible = false;
            addtopicbtn.Visible = false;


            crs_id_addcrs_lable.Visible = true;
            crs_name_addcrs_lable.Visible = true;
            crsname_txt.Visible = true;
            crsidaddcourse_txt.Visible = true;
            addcrsbtndet.Visible = true;
            crsHours_lab.Visible = true;
            crshours_txt.Visible = true;

            id_label.Visible = false;
            Name_Label.Visible = false;
            Salary_lable.Visible = false;
            dob_lable.Visible = false;
            Ciy_Lable.Visible = false;
            Phone_Lable.Visible = false;
            email_lable.Visible = false;
            Gender_label.Visible = false;


        }

        private void AddTopicsbtn_Click(object sender, EventArgs e)
        {
            pictureBox2.Visible = false;
            dataGridView1.Visible = false;


            crs_id_addcrs_lable.Visible = true;
            crs_name_addcrs_lable.Visible = false;
            topbame_txt.Visible = true;
            TopName_lab.Visible = true;
            addtopicbtn.Visible = true;

            crsname_txt.Visible = false;
            crsidaddcourse_txt.Visible = true;
            addcrsbtndet.Visible = false;
            crsHours_lab.Visible = false;
            crshours_txt.Visible = false;

            id_label.Visible = false;
            Name_Label.Visible = false;
            Salary_lable.Visible = false;
            dob_lable.Visible = false;
            Ciy_Lable.Visible = false;
            Phone_Lable.Visible = false;
            email_lable.Visible = false;
            Gender_label.Visible = false;

        }

        private void button1_Click(object sender, EventArgs e)
        {
            pictureBox2.Visible = false;
            addtopicbtn.Visible = false;

            crs_id_addcrs_lable.Visible = false;
            crs_name_addcrs_lable.Visible = false;
            topbame_txt.Visible = false;
            TopName_lab.Visible = false;

            id_label.Visible = false;
            Name_Label.Visible = false;
            Salary_lable.Visible = false;
            dob_lable.Visible = false;
            Ciy_Lable.Visible = false;
            Phone_Lable.Visible = false;
            email_lable.Visible = false;
            Gender_label.Visible = false;

            crsname_txt.Visible = false;
            crsidaddcourse_txt.Visible = false;
            addcrsbtndet.Visible = false;
            crsHours_lab.Visible = false;
            crshours_txt.Visible = false;

            dataGridView1.Visible = true;

            var param = new SqlParameter[] {
                                    new SqlParameter() {
                                        ParameterName = "@insid",
                                        SqlDbType =  System.Data.SqlDbType.Int,
                                        Size = 100,
                                        Direction = System.Data.ParameterDirection.Input,
                                        Value = id
                                    },
                                   };
            List<Instructorcourses> coursestList = ExamSys.Instructorcourses.FromSqlRaw("[dbo].[inscourses] @insID", param).ToList();
            

            dataGridView1.DataSource = coursestList;

        }

        private void addcrsbtndet_Click(object sender, EventArgs e)
        {
            Courses crs = new Courses();
            crs.CrsName = crsname_txt.Text;
            int _id;
            if (Int32.TryParse(crsidaddcourse_txt.Text, out _id))
            {
                crs.CrsId = _id;
            }
            int _hours;
            if (Int32.TryParse(crshours_txt.Text, out _hours))
            {
                crs.Hours = _hours;
            }

            try
            {
                ExamSys.Courses.Add(crs);
                ExamSys.SaveChanges();
                crsname_txt.Text = "";
                crsidaddcourse_txt.Text = "";
                crshours_txt.Text = "";
                MessageBox.Show("Added!");

            }
            catch (Exception)
            {

                MessageBox.Show("Course ID not valid");
            }
            

        }

        private void crsidaddcourse_txt_TextChanged(object sender, EventArgs e)
        {

        }

        private void addtopicbtn_Click(object sender, EventArgs e)
        {
            Topics top = new Topics();
            int _id;
            if (Int32.TryParse(crsidaddcourse_txt.Text, out _id))
            {
                top.CrsId = _id;
            }
            top.TopName = topbame_txt.Text;

            try
            {
                ExamSys.Topics.Add(top);
                ExamSys.SaveChanges();

                crsidaddcourse_txt.Text = "";
                topbame_txt.Text = "";
                MessageBox.Show("Added!");

            }
            catch (Exception)
            {

                MessageBox.Show("Course ID not valid");

            }



        }

        private void insinfo_btn_Click(object sender, EventArgs e)
        {

            id_label.Visible = true;
            Name_Label.Visible = true;
            Salary_lable.Visible = true;
            dob_lable.Visible = true;
            Ciy_Lable.Visible = true;
            Phone_Lable.Visible = true;
            email_lable.Visible = true;
            Gender_label.Visible = true;

            pictureBox2.Visible = false;
            addtopicbtn.Visible = false;
            crs_id_addcrs_lable.Visible = false;
            crs_name_addcrs_lable.Visible = false;
            topbame_txt.Visible = false;
            TopName_lab.Visible = false;
            crsname_txt.Visible = false;
            crsidaddcourse_txt.Visible = false;
            addcrsbtndet.Visible = false;
            crsHours_lab.Visible = false;
            crshours_txt.Visible = false;
            dataGridView1.Visible = false;

            Instructors I  = ExamSys.Instructors.FirstOrDefault(x => x.InsId == id);

            id_label.Text = "ID: " + id;
            Name_Label.Text = "Name: " + name;
            Salary_lable.Text = "Salary: " + I.Salary;
            Ciy_Lable.Text = "City: " + I.City;
            dob_lable.Text = "Date of birth: " + I.Dob;
            Phone_Lable.Text = "Phone Number: " + I.PhoneNumber;
            Gender_label.Text = "Gender: " + I.Gender;
            email_lable.Text = "E-mail: " + I.Email; 
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
