﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using ExamnationSystem00.Models;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;

namespace ExamnationSystem00
{
    public partial class Exam : Form
    {
        ExamDB ExamSys = new ExamDB();

        private const CommandType storedProcedure = CommandType.StoredProcedure;
        string submitted_answer1;
        string submitted_answer2;
        string submitted_answer3;
        string submitted_answer4;
        string submitted_answer5;
        string submitted_answer6;
        string submitted_answer7;
        string submitted_answer8;
        string submitted_answer9;
        string submitted_answer10;
        int exam_id , crs_id, id;
        List<string> lst = new List<string>();
        List<int> QID = new List<int>();
        public Exam( int _crs_id , int _id)
        {
            crs_id = _crs_id;
            id = _id;
            Random rnd = new Random();
            exam_id = rnd.Next(100, 100000);
            InitializeComponent();
            string name, Choice;
            label1.Text = "Exam No." + exam_id;
           
            int qqq = 11;

            SqlConnection conn = new SqlConnection("Data Source=.;Initial Catalog=ExamSystem;Integrated Security=True");
            conn.Open();

            SqlCommand SaveExaminf = new SqlCommand("SaveExamInfo", conn);
            SaveExaminf.CommandType = CommandType.StoredProcedure;
            SaveExaminf.Parameters.AddWithValue("@CrsID", crs_id);
            SaveExaminf.Parameters.AddWithValue("@ExID", exam_id);
            SaveExaminf.ExecuteScalar();

            SqlCommand quest_genr_MCQ = new SqlCommand("MCQues", conn);
            quest_genr_MCQ.CommandType = CommandType.StoredProcedure;
            quest_genr_MCQ.Parameters.AddWithValue("@CrsID", crs_id);

            SqlCommand quest_genr_TF = new SqlCommand("TFQues", conn);
            quest_genr_TF.CommandType = CommandType.StoredProcedure;
            quest_genr_TF.Parameters.AddWithValue("@CrsID", crs_id);

            SqlCommand First_Ch = new SqlCommand("choise1", conn);
            First_Ch.CommandType = CommandType.StoredProcedure;

            SqlCommand Second_Ch = new SqlCommand("choise2", conn);
            Second_Ch.CommandType = CommandType.StoredProcedure;

            SqlCommand Third_Ch = new SqlCommand("choise3", conn);
            Third_Ch.CommandType = CommandType.StoredProcedure;

            SqlCommand Fourth_Ch = new SqlCommand("choise4", conn);
            Fourth_Ch.CommandType = CommandType.StoredProcedure;


            int count = 0;
            for (int i = 0; i <= 9; i++)
            {
                name = Convert.ToString(quest_genr_MCQ.ExecuteScalar());
                count++;
                if (!lst.Contains(name))
                {
                    lst.Add(name);
                    Questions Q = ExamSys.Questions.FirstOrDefault(x => x.QuesContent == name);
                    QID.Add(Q.QuesId);
                }
            }
            for (int i = 0; i <= 4; i++)
            {
                name = Convert.ToString(quest_genr_TF.ExecuteScalar());
                count++;
                if (!lst.Contains(name))
                {
                    lst.Add(name);
                    Questions Q = ExamSys.Questions.FirstOrDefault(x => x.QuesContent == name);
                    QID.Add(Q.QuesId);
                }
            }
            if (count >= 4)
            {
                q1.Text = "1- " + Convert.ToString(lst[0]);
                q2.Text = "2- " + Convert.ToString(lst[1]);
                q3.Text = "3- " + Convert.ToString(lst[2]);
                q4.Text = "4- " + Convert.ToString(lst[3]);
                q5.Text = "5- " + Convert.ToString(lst[4]);
                q6.Text = "6- " + Convert.ToString(lst[5]);
                q7.Text = "7- " + Convert.ToString(lst[6]);
                q8.Text = "8- " + Convert.ToString(lst[7]);
                q9.Text = "9- " + Convert.ToString(lst[8]);
                q10.Text = "10- " + Convert.ToString(lst[9]);

            }

            // First Ques Options 
            First_Ch.Parameters.AddWithValue("@quesid", QID[0]);
            Choice = Convert.ToString(First_Ch.ExecuteScalar());
            r1_1.Text = Choice;
            Second_Ch.Parameters.AddWithValue("@quesid", QID[0]);
            Choice = Convert.ToString(Second_Ch.ExecuteScalar());
            r1_2.Text = Choice;
            Third_Ch.Parameters.AddWithValue("@quesid", QID[0]);
            Choice = Convert.ToString(Third_Ch.ExecuteScalar());
            r1_3.Text = Choice;
            Fourth_Ch.Parameters.AddWithValue("@quesid", QID[0]);
            Choice = Convert.ToString(Fourth_Ch.ExecuteScalar());
            r1_4.Text = Choice;

            First_Ch.Parameters.Clear();
            Second_Ch.Parameters.Clear();
            Third_Ch.Parameters.Clear();
            Fourth_Ch.Parameters.Clear();

            // Second Ques Options 
            First_Ch.Parameters.AddWithValue("@quesid", QID[1]);
            Choice = Convert.ToString(First_Ch.ExecuteScalar());
            r2_1.Text = Choice;
            Second_Ch.Parameters.AddWithValue("@quesid", QID[1]);
            Choice = Convert.ToString(Second_Ch.ExecuteScalar());
            r2_2.Text = Choice;
            Third_Ch.Parameters.AddWithValue("@quesid", QID[1]);
            Choice = Convert.ToString(Third_Ch.ExecuteScalar());
            r2_3.Text = Choice;
            Fourth_Ch.Parameters.AddWithValue("@quesid", QID[1]);
            Choice = Convert.ToString(Fourth_Ch.ExecuteScalar());
            r2_4.Text = Choice;

            First_Ch.Parameters.Clear();
            Second_Ch.Parameters.Clear();
            Third_Ch.Parameters.Clear();
            Fourth_Ch.Parameters.Clear();

            // Third Ques Options 
            First_Ch.Parameters.AddWithValue("@quesid", QID[2]);
            Choice = Convert.ToString(First_Ch.ExecuteScalar());
            r3_1.Text = Choice;
            Second_Ch.Parameters.AddWithValue("@quesid", QID[2]);
            Choice = Convert.ToString(Second_Ch.ExecuteScalar());
            r3_2.Text = Choice;
            Third_Ch.Parameters.AddWithValue("@quesid", QID[2]);
            Choice = Convert.ToString(Third_Ch.ExecuteScalar());
            r3_3.Text = Choice;
            Fourth_Ch.Parameters.AddWithValue("@quesid", QID[2]);
            Choice = Convert.ToString(Fourth_Ch.ExecuteScalar());
            r3_4.Text = Choice;


            First_Ch.Parameters.Clear();
            Second_Ch.Parameters.Clear();
            Third_Ch.Parameters.Clear();
            Fourth_Ch.Parameters.Clear();


            // 4th Ques Options 
            First_Ch.Parameters.AddWithValue("@quesid", QID[3]);
            Choice = Convert.ToString(First_Ch.ExecuteScalar());
            r4_1.Text = Choice;
            Second_Ch.Parameters.AddWithValue("@quesid", QID[3]);
            Choice = Convert.ToString(Second_Ch.ExecuteScalar());
            r4_2.Text = Choice;
            Third_Ch.Parameters.AddWithValue("@quesid", QID[3]);
            Choice = Convert.ToString(Third_Ch.ExecuteScalar());
            r4_3.Text = Choice;
            Fourth_Ch.Parameters.AddWithValue("@quesid", QID[3]);
            Choice = Convert.ToString(Fourth_Ch.ExecuteScalar());
            r4_4.Text = Choice;


            First_Ch.Parameters.Clear();
            Second_Ch.Parameters.Clear();
            Third_Ch.Parameters.Clear();
            Fourth_Ch.Parameters.Clear();


            // 5th Ques Options 
            First_Ch.Parameters.AddWithValue("@quesid", QID[4]);
            Choice = Convert.ToString(First_Ch.ExecuteScalar());
            r5_1.Text = Choice;
            Second_Ch.Parameters.AddWithValue("@quesid", QID[4]);
            Choice = Convert.ToString(Second_Ch.ExecuteScalar());
            r5_2.Text = Choice;
            Third_Ch.Parameters.AddWithValue("@quesid", QID[4]);
            Choice = Convert.ToString(Third_Ch.ExecuteScalar());
            r5_3.Text = Choice;
            Fourth_Ch.Parameters.AddWithValue("@quesid", QID[4]);
            Choice = Convert.ToString(Fourth_Ch.ExecuteScalar());
            r5_4.Text = Choice;

            First_Ch.Parameters.Clear();
            Second_Ch.Parameters.Clear();
            Third_Ch.Parameters.Clear();
            Fourth_Ch.Parameters.Clear();

            // 6th Ques Options 
            First_Ch.Parameters.AddWithValue("@quesid", QID[5]);
            Choice = Convert.ToString(First_Ch.ExecuteScalar());
            r6_1.Text = Choice;
            Second_Ch.Parameters.AddWithValue("@quesid", QID[5]);
            Choice = Convert.ToString(Second_Ch.ExecuteScalar());
            r6_2.Text = Choice;
            Third_Ch.Parameters.AddWithValue("@quesid", QID[5]);
            Choice = Convert.ToString(Third_Ch.ExecuteScalar());
            r6_3.Text = Choice;
            Fourth_Ch.Parameters.AddWithValue("@quesid", QID[5]);
            Choice = Convert.ToString(Fourth_Ch.ExecuteScalar());
            r6_4.Text = Choice;

            First_Ch.Parameters.Clear();
            Second_Ch.Parameters.Clear();
            Third_Ch.Parameters.Clear();
            Fourth_Ch.Parameters.Clear();

            // 7th Ques Options 
            First_Ch.Parameters.AddWithValue("@quesid", QID[6]);
            Choice = Convert.ToString(First_Ch.ExecuteScalar());
            r7_1.Text = Choice;
            Second_Ch.Parameters.AddWithValue("@quesid", QID[6]);
            Choice = Convert.ToString(Second_Ch.ExecuteScalar());
            r7_2.Text = Choice;
            Third_Ch.Parameters.AddWithValue("@quesid", QID[6]);
            Choice = Convert.ToString(Third_Ch.ExecuteScalar());
            r7_3.Text = Choice;
            Fourth_Ch.Parameters.AddWithValue("@quesid", QID[6]);
            Choice = Convert.ToString(Fourth_Ch.ExecuteScalar());
            r7_4.Text = Choice;

            First_Ch.Parameters.Clear();
            Second_Ch.Parameters.Clear();
            Third_Ch.Parameters.Clear();
            Fourth_Ch.Parameters.Clear();


            // 8th Ques Options 
            First_Ch.Parameters.AddWithValue("@quesid", QID[7]);
            Choice = Convert.ToString(First_Ch.ExecuteScalar());
            r8_1.Text = Choice;
            Second_Ch.Parameters.AddWithValue("@quesid", QID[7]);
            Choice = Convert.ToString(Second_Ch.ExecuteScalar());
            r8_2.Text = Choice;
            Third_Ch.Parameters.AddWithValue("@quesid", QID[7]);
            Choice = Convert.ToString(Third_Ch.ExecuteScalar());
            r8_3.Text = Choice;
            Fourth_Ch.Parameters.AddWithValue("@quesid", QID[7]);
            Choice = Convert.ToString(Fourth_Ch.ExecuteScalar());
            r8_4.Text = Choice;

            First_Ch.Parameters.Clear();
            Second_Ch.Parameters.Clear();
            Third_Ch.Parameters.Clear();
            Fourth_Ch.Parameters.Clear();


            // 9th Ques Options 
            First_Ch.Parameters.AddWithValue("@quesid", QID[8]);
            Choice = Convert.ToString(First_Ch.ExecuteScalar());
            r9_1.Text = Choice;
            Second_Ch.Parameters.AddWithValue("@quesid", QID[8]);
            Choice = Convert.ToString(Second_Ch.ExecuteScalar());
            r9_2.Text = Choice;
            Third_Ch.Parameters.AddWithValue("@quesid", QID[8]);
            Choice = Convert.ToString(Third_Ch.ExecuteScalar());
           // r9_3.Text = Choice;
            Fourth_Ch.Parameters.AddWithValue("@quesid", QID[8]);
            Choice = Convert.ToString(Fourth_Ch.ExecuteScalar());
            // r9_4.Text = Choice;

            First_Ch.Parameters.Clear();
            Second_Ch.Parameters.Clear();
            Third_Ch.Parameters.Clear();
            Fourth_Ch.Parameters.Clear();

            // 10th Ques Options 
            First_Ch.Parameters.AddWithValue("@quesid", QID[9]);
            Choice = Convert.ToString(First_Ch.ExecuteScalar());
            r10_1.Text = Choice;
            Second_Ch.Parameters.AddWithValue("@quesid", QID[9]);
            Choice = Convert.ToString(Second_Ch.ExecuteScalar());
            r10_2.Text = Choice;
            Third_Ch.Parameters.AddWithValue("@quesid", QID[9]);
            Choice = Convert.ToString(Third_Ch.ExecuteScalar());
           // r10_3.Text = Choice;
            Fourth_Ch.Parameters.AddWithValue("@quesid", QID[9]);
            Choice = Convert.ToString(Fourth_Ch.ExecuteScalar());
            //r10_4.Text = Choice;






        }



        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Finish_btn_Click(object sender, EventArgs e)
        {
            if (r1_1.Checked)
                submitted_answer1 = r1_1.Text;
            else if (r1_2.Checked)
                submitted_answer1 = r1_2.Text;
            else if (r1_3.Checked)
                submitted_answer1 = r1_3.Text;
            else if (r1_4.Checked)
                submitted_answer1 = r1_4.Text;

            if (r2_1.Checked)
                submitted_answer2 = r2_1.Text;
            else if (r2_2.Checked)
                submitted_answer2 = r2_2.Text;
            else if (r2_3.Checked)
                submitted_answer2 = r2_3.Text;
            else if (r2_4.Checked)
                submitted_answer2 = r2_4.Text;

            if (r3_1.Checked)
                submitted_answer3 = r3_1.Text;
            else if (r3_2.Checked)
                submitted_answer3 = r3_2.Text;
            else if (r3_3.Checked)
                submitted_answer3 = r3_3.Text;
            else if (r3_4.Checked)
                submitted_answer3 = r3_4.Text;

            if (r4_1.Checked)
                submitted_answer4 = r4_1.Text;
            else if (r4_2.Checked)
                submitted_answer4 = r4_2.Text;
            else if (r4_3.Checked)
                submitted_answer4 = r4_3.Text;
            else if (r4_4.Checked)
                submitted_answer4 = r4_4.Text;

            if (r5_1.Checked)
                submitted_answer5 = r5_1.Text;
            else if (r5_2.Checked)
                submitted_answer5 = r5_2.Text;
            else if (r5_3.Checked)
                submitted_answer5 = r5_3.Text;
            else if (r5_4.Checked)
                submitted_answer5 = r5_4.Text;

            if (r6_1.Checked)
                submitted_answer6 = r6_1.Text;
            else if (r6_2.Checked)
                submitted_answer6 = r6_2.Text;
            else if (r6_3.Checked)
                submitted_answer6 = r6_3.Text;
            else if (r6_4.Checked)
                submitted_answer6 = r6_4.Text;

            if (r7_1.Checked)
                submitted_answer7 = r7_1.Text;
            else if (r7_2.Checked)
                submitted_answer7 = r7_2.Text;
            else if (r7_3.Checked)
                submitted_answer7 = r7_3.Text;
            else if (r7_4.Checked)
                submitted_answer7 = r7_4.Text;


            if (r8_1.Checked)
                submitted_answer8 = r8_1.Text;
            else if (r8_2.Checked)
                submitted_answer8 = r8_2.Text;
            else if (r8_3.Checked)
                submitted_answer8 = r8_3.Text;
            else if (r8_4.Checked)
                submitted_answer8 = r8_4.Text;

            if (r9_1.Checked)
                submitted_answer9 = r9_1.Text;
            else if (r9_2.Checked)
                submitted_answer9 = r9_2.Text;


            if (r10_1.Checked)
                submitted_answer10 = r10_1.Text;
            else if (r10_2.Checked)
                submitted_answer10 = r10_2.Text;

            SqlConnection conn = new SqlConnection("Data Source=.;Initial Catalog=ExamSystem;Integrated Security=True");
            conn.Open();
            SqlCommand Save = new SqlCommand("SaveOneAnswer", conn);
            Save.CommandType = CommandType.StoredProcedure;


            try
            {

           
            Save.Parameters.AddWithValue("@StID", id);
            Save.Parameters.AddWithValue("@ExID", exam_id);
            Save.Parameters.AddWithValue("@QuesID", QID[0]);
            Save.Parameters.AddWithValue("@StAns", submitted_answer1);
            Save.ExecuteScalar();
            Save.Parameters.Clear();
          

            Save.Parameters.AddWithValue("@StID", id);
            Save.Parameters.AddWithValue("@ExID", exam_id);
            Save.Parameters.AddWithValue("@QuesID", QID[1]);
            Save.Parameters.AddWithValue("@StAns", submitted_answer2);
            Save.ExecuteScalar();
            Save.Parameters.Clear();

            Save.Parameters.AddWithValue("@StID", id);
            Save.Parameters.AddWithValue("@ExID", exam_id);
            Save.Parameters.AddWithValue("@QuesID", QID[2]);
            Save.Parameters.AddWithValue("@StAns", submitted_answer3);
            Save.ExecuteScalar();
            Save.Parameters.Clear();

            Save.Parameters.AddWithValue("@StID", id);
            Save.Parameters.AddWithValue("@ExID", exam_id);
            Save.Parameters.AddWithValue("@QuesID", QID[3]);
            Save.Parameters.AddWithValue("@StAns", submitted_answer4);
            Save.ExecuteScalar();
            Save.Parameters.Clear();

            Save.Parameters.AddWithValue("@StID", id);
            Save.Parameters.AddWithValue("@ExID", exam_id);
            Save.Parameters.AddWithValue("@QuesID", QID[4]);
            Save.Parameters.AddWithValue("@StAns", submitted_answer5);
            Save.ExecuteScalar();
            Save.Parameters.Clear();

            Save.Parameters.AddWithValue("@StID", id);
            Save.Parameters.AddWithValue("@ExID", exam_id);
            Save.Parameters.AddWithValue("@QuesID", QID[5]);
            Save.Parameters.AddWithValue("@StAns", submitted_answer6);
            Save.ExecuteScalar();
            Save.Parameters.Clear();


            Save.Parameters.AddWithValue("@StID", id);
            Save.Parameters.AddWithValue("@ExID", exam_id);
            Save.Parameters.AddWithValue("@QuesID", QID[6]);
            Save.Parameters.AddWithValue("@StAns", submitted_answer7);
            Save.ExecuteScalar();
            Save.Parameters.Clear();


            Save.Parameters.AddWithValue("@StID", id);
            Save.Parameters.AddWithValue("@ExID", exam_id);
            Save.Parameters.AddWithValue("@QuesID", QID[7]);
            Save.Parameters.AddWithValue("@StAns", submitted_answer8);
            Save.ExecuteScalar();
            Save.Parameters.Clear();


            Save.Parameters.AddWithValue("@StID", id);
            Save.Parameters.AddWithValue("@ExID", exam_id);
            Save.Parameters.AddWithValue("@QuesID", QID[8]);
            Save.Parameters.AddWithValue("@StAns", submitted_answer9);
            Save.ExecuteScalar();
            Save.Parameters.Clear();

            Save.Parameters.AddWithValue("@StID", id);
            Save.Parameters.AddWithValue("@ExID", exam_id);
            Save.Parameters.AddWithValue("@QuesID", QID[9]);
            Save.Parameters.AddWithValue("@StAns", submitted_answer10);
            Save.ExecuteScalar();
            Save.Parameters.Clear();

            }
            catch (Exception)
            {

                MessageBox.Show("Please Answer All Questions");
            }

            Result R = new Result(id, exam_id);
            R.ShowDialog();
            this.Close();

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void Exam_Load(object sender, EventArgs e)
        {

        }

        private void q1_Click(object sender, EventArgs e)
        {

        }
    }
}
