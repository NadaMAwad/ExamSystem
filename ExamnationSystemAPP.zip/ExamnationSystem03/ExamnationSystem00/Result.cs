﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ExamnationSystem00.Models;
using Microsoft.Data.SqlClient;

namespace ExamnationSystem00
{
    public partial class Result : Form
    {
        ExamDB ExamSys = new ExamDB();
        int St_id, Ex_id;
        int R;
        public Result(int _Stid, int _Exid)
        {
            InitializeComponent();
            St_id = _Stid;  
            Ex_id = _Exid;
            SqlConnection conn = new SqlConnection("Data Source=.;Initial Catalog=ExamSystem;Integrated Security=True");
            conn.Open();

            SqlCommand Results = new SqlCommand("ExamResult", conn);
            Results.CommandType = CommandType.StoredProcedure;


            Results.Parameters.AddWithValue("@StID", St_id);
            Results.Parameters.AddWithValue("@ExID", Ex_id);
            R  = Convert.ToInt32(Results.ExecuteScalar());
            label2.Text = "You Score is " + R + " / 10";

            if (R>5)
            {
                label1.Text = "Congratiolations!";
                pictureBox1.Visible = true;
                pictureBox2.Visible = false;

            }
            else
            {
                label1.Text = "Try Again! You Can Do It!";
                pictureBox1.Visible = false;
                pictureBox2.Visible = true;


            }



        }

        private void Result_Load(object sender, EventArgs e)
        {

        }
    }
}
