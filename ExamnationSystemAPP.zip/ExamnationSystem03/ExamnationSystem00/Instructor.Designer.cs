﻿namespace ExamnationSystem00
{
    partial class Instructor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.insinfo_btn = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.AddCoursebtn = new System.Windows.Forms.Button();
            this.AddTopicsbtn = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.crs_id_addcrs_lable = new System.Windows.Forms.Label();
            this.crs_name_addcrs_lable = new System.Windows.Forms.Label();
            this.crsidaddcourse_txt = new System.Windows.Forms.TextBox();
            this.crsname_txt = new System.Windows.Forms.TextBox();
            this.addcrsbtndet = new System.Windows.Forms.Button();
            this.crshours_txt = new System.Windows.Forms.TextBox();
            this.crsHours_lab = new System.Windows.Forms.Label();
            this.TopName_lab = new System.Windows.Forms.Label();
            this.topbame_txt = new System.Windows.Forms.TextBox();
            this.addtopicbtn = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.email_lable = new System.Windows.Forms.Label();
            this.Gender_label = new System.Windows.Forms.Label();
            this.Phone_Lable = new System.Windows.Forms.Label();
            this.dob_lable = new System.Windows.Forms.Label();
            this.Ciy_Lable = new System.Windows.Forms.Label();
            this.Salary_lable = new System.Windows.Forms.Label();
            this.Name_Label = new System.Windows.Forms.Label();
            this.id_label = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.insinfo_btn);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.AddCoursebtn);
            this.panel1.Controls.Add(this.AddTopicsbtn);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(250, 656);
            this.panel1.TabIndex = 0;
            // 
            // insinfo_btn
            // 
            this.insinfo_btn.BackColor = System.Drawing.Color.LightGray;
            this.insinfo_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.insinfo_btn.FlatAppearance.BorderSize = 0;
            this.insinfo_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.insinfo_btn.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.insinfo_btn.Location = new System.Drawing.Point(2, 214);
            this.insinfo_btn.Name = "insinfo_btn";
            this.insinfo_btn.Size = new System.Drawing.Size(247, 29);
            this.insinfo_btn.TabIndex = 6;
            this.insinfo_btn.Text = "Your information";
            this.insinfo_btn.UseVisualStyleBackColor = false;
            this.insinfo_btn.Click += new System.EventHandler(this.insinfo_btn_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(60, 152);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 23);
            this.label1.TabIndex = 5;
            this.label1.Text = "label1";
            // 
            // AddCoursebtn
            // 
            this.AddCoursebtn.BackColor = System.Drawing.Color.LightGray;
            this.AddCoursebtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.AddCoursebtn.FlatAppearance.BorderSize = 0;
            this.AddCoursebtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.AddCoursebtn.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.AddCoursebtn.Location = new System.Drawing.Point(0, 352);
            this.AddCoursebtn.Name = "AddCoursebtn";
            this.AddCoursebtn.Size = new System.Drawing.Size(247, 29);
            this.AddCoursebtn.TabIndex = 4;
            this.AddCoursebtn.Text = "Add Course";
            this.AddCoursebtn.UseVisualStyleBackColor = false;
            this.AddCoursebtn.Click += new System.EventHandler(this.AddCoursebtn_Click);
            // 
            // AddTopicsbtn
            // 
            this.AddTopicsbtn.BackColor = System.Drawing.Color.LightGray;
            this.AddTopicsbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.AddTopicsbtn.FlatAppearance.BorderSize = 0;
            this.AddTopicsbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.AddTopicsbtn.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.AddTopicsbtn.Location = new System.Drawing.Point(0, 303);
            this.AddTopicsbtn.Name = "AddTopicsbtn";
            this.AddTopicsbtn.Size = new System.Drawing.Size(247, 29);
            this.AddTopicsbtn.TabIndex = 3;
            this.AddTopicsbtn.Text = "Add Topics";
            this.AddTopicsbtn.UseVisualStyleBackColor = false;
            this.AddTopicsbtn.Click += new System.EventHandler(this.AddTopicsbtn_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.LightGray;
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button1.Location = new System.Drawing.Point(0, 257);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(247, 29);
            this.button1.TabIndex = 1;
            this.button1.Text = "Your Courses";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::ExamnationSystem00.Properties.Resources.iti_logo_5b9a0fd125be_300x133;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(250, 120);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::ExamnationSystem00.Properties.Resources._6101073;
            this.pictureBox2.Location = new System.Drawing.Point(253, 0);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(797, 656);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            // 
            // crs_id_addcrs_lable
            // 
            this.crs_id_addcrs_lable.AutoSize = true;
            this.crs_id_addcrs_lable.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.crs_id_addcrs_lable.Location = new System.Drawing.Point(459, 211);
            this.crs_id_addcrs_lable.Name = "crs_id_addcrs_lable";
            this.crs_id_addcrs_lable.Size = new System.Drawing.Size(77, 20);
            this.crs_id_addcrs_lable.TabIndex = 6;
            this.crs_id_addcrs_lable.Text = "Course ID";
            // 
            // crs_name_addcrs_lable
            // 
            this.crs_name_addcrs_lable.AutoSize = true;
            this.crs_name_addcrs_lable.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.crs_name_addcrs_lable.Location = new System.Drawing.Point(450, 288);
            this.crs_name_addcrs_lable.Name = "crs_name_addcrs_lable";
            this.crs_name_addcrs_lable.Size = new System.Drawing.Size(103, 20);
            this.crs_name_addcrs_lable.TabIndex = 7;
            this.crs_name_addcrs_lable.Text = "Course Name";
            // 
            // crsidaddcourse_txt
            // 
            this.crsidaddcourse_txt.Location = new System.Drawing.Point(566, 211);
            this.crsidaddcourse_txt.Name = "crsidaddcourse_txt";
            this.crsidaddcourse_txt.Size = new System.Drawing.Size(224, 27);
            this.crsidaddcourse_txt.TabIndex = 6;
            this.crsidaddcourse_txt.TextChanged += new System.EventHandler(this.crsidaddcourse_txt_TextChanged);
            // 
            // crsname_txt
            // 
            this.crsname_txt.Location = new System.Drawing.Point(566, 286);
            this.crsname_txt.Name = "crsname_txt";
            this.crsname_txt.Size = new System.Drawing.Size(224, 27);
            this.crsname_txt.TabIndex = 8;
            // 
            // addcrsbtndet
            // 
            this.addcrsbtndet.BackColor = System.Drawing.Color.LightGray;
            this.addcrsbtndet.Cursor = System.Windows.Forms.Cursors.Hand;
            this.addcrsbtndet.FlatAppearance.BorderSize = 0;
            this.addcrsbtndet.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.addcrsbtndet.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.addcrsbtndet.Location = new System.Drawing.Point(566, 426);
            this.addcrsbtndet.Name = "addcrsbtndet";
            this.addcrsbtndet.Size = new System.Drawing.Size(140, 29);
            this.addcrsbtndet.TabIndex = 6;
            this.addcrsbtndet.Text = "Add Course";
            this.addcrsbtndet.UseVisualStyleBackColor = false;
            this.addcrsbtndet.Click += new System.EventHandler(this.addcrsbtndet_Click);
            // 
            // crshours_txt
            // 
            this.crshours_txt.Location = new System.Drawing.Point(566, 358);
            this.crshours_txt.Name = "crshours_txt";
            this.crshours_txt.Size = new System.Drawing.Size(224, 27);
            this.crshours_txt.TabIndex = 10;
            // 
            // crsHours_lab
            // 
            this.crsHours_lab.AutoSize = true;
            this.crsHours_lab.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.crsHours_lab.Location = new System.Drawing.Point(450, 361);
            this.crsHours_lab.Name = "crsHours_lab";
            this.crsHours_lab.Size = new System.Drawing.Size(103, 20);
            this.crsHours_lab.TabIndex = 9;
            this.crsHours_lab.Text = "Course Hours";
            // 
            // TopName_lab
            // 
            this.TopName_lab.AutoSize = true;
            this.TopName_lab.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.TopName_lab.Location = new System.Drawing.Point(450, 288);
            this.TopName_lab.Name = "TopName_lab";
            this.TopName_lab.Size = new System.Drawing.Size(92, 20);
            this.TopName_lab.TabIndex = 11;
            this.TopName_lab.Text = "Topic Name";
            // 
            // topbame_txt
            // 
            this.topbame_txt.Location = new System.Drawing.Point(566, 285);
            this.topbame_txt.Name = "topbame_txt";
            this.topbame_txt.Size = new System.Drawing.Size(224, 27);
            this.topbame_txt.TabIndex = 12;
            // 
            // addtopicbtn
            // 
            this.addtopicbtn.BackColor = System.Drawing.Color.LightGray;
            this.addtopicbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.addtopicbtn.FlatAppearance.BorderSize = 0;
            this.addtopicbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.addtopicbtn.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.addtopicbtn.Location = new System.Drawing.Point(566, 352);
            this.addtopicbtn.Name = "addtopicbtn";
            this.addtopicbtn.Size = new System.Drawing.Size(140, 29);
            this.addtopicbtn.TabIndex = 13;
            this.addtopicbtn.Text = "Add Topic";
            this.addtopicbtn.UseVisualStyleBackColor = false;
            this.addtopicbtn.Click += new System.EventHandler(this.addtopicbtn_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridView1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.Silver;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.Silver;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView1.Location = new System.Drawing.Point(488, 205);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 29;
            this.dataGridView1.Size = new System.Drawing.Size(357, 215);
            this.dataGridView1.TabIndex = 6;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // email_lable
            // 
            this.email_lable.AutoSize = true;
            this.email_lable.BackColor = System.Drawing.Color.Silver;
            this.email_lable.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.email_lable.ForeColor = System.Drawing.Color.Black;
            this.email_lable.Location = new System.Drawing.Point(404, 253);
            this.email_lable.Name = "email_lable";
            this.email_lable.Size = new System.Drawing.Size(64, 28);
            this.email_lable.TabIndex = 21;
            this.email_lable.Text = "email";
            // 
            // Gender_label
            // 
            this.Gender_label.AutoSize = true;
            this.Gender_label.BackColor = System.Drawing.Color.Silver;
            this.Gender_label.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Gender_label.ForeColor = System.Drawing.Color.Black;
            this.Gender_label.Location = new System.Drawing.Point(404, 361);
            this.Gender_label.Name = "Gender_label";
            this.Gender_label.Size = new System.Drawing.Size(78, 28);
            this.Gender_label.TabIndex = 20;
            this.Gender_label.Text = "gender";
            // 
            // Phone_Lable
            // 
            this.Phone_Lable.AutoSize = true;
            this.Phone_Lable.BackColor = System.Drawing.Color.Silver;
            this.Phone_Lable.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Phone_Lable.ForeColor = System.Drawing.Color.Black;
            this.Phone_Lable.Location = new System.Drawing.Point(404, 433);
            this.Phone_Lable.Name = "Phone_Lable";
            this.Phone_Lable.Size = new System.Drawing.Size(71, 28);
            this.Phone_Lable.TabIndex = 19;
            this.Phone_Lable.Text = "phone";
            // 
            // dob_lable
            // 
            this.dob_lable.AutoSize = true;
            this.dob_lable.BackColor = System.Drawing.Color.Silver;
            this.dob_lable.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.dob_lable.ForeColor = System.Drawing.Color.Black;
            this.dob_lable.Location = new System.Drawing.Point(404, 397);
            this.dob_lable.Name = "dob_lable";
            this.dob_lable.Size = new System.Drawing.Size(48, 28);
            this.dob_lable.TabIndex = 18;
            this.dob_lable.Text = "dob";
            // 
            // Ciy_Lable
            // 
            this.Ciy_Lable.AutoSize = true;
            this.Ciy_Lable.BackColor = System.Drawing.Color.Silver;
            this.Ciy_Lable.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Ciy_Lable.ForeColor = System.Drawing.Color.Black;
            this.Ciy_Lable.Location = new System.Drawing.Point(404, 325);
            this.Ciy_Lable.Name = "Ciy_Lable";
            this.Ciy_Lable.Size = new System.Drawing.Size(47, 28);
            this.Ciy_Lable.TabIndex = 17;
            this.Ciy_Lable.Text = "city";
            // 
            // Salary_lable
            // 
            this.Salary_lable.AutoSize = true;
            this.Salary_lable.BackColor = System.Drawing.Color.Silver;
            this.Salary_lable.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Salary_lable.ForeColor = System.Drawing.Color.Black;
            this.Salary_lable.Location = new System.Drawing.Point(404, 289);
            this.Salary_lable.Name = "Salary_lable";
            this.Salary_lable.Size = new System.Drawing.Size(71, 28);
            this.Salary_lable.TabIndex = 16;
            this.Salary_lable.Text = "Salary";
            // 
            // Name_Label
            // 
            this.Name_Label.AutoSize = true;
            this.Name_Label.BackColor = System.Drawing.Color.Silver;
            this.Name_Label.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Name_Label.ForeColor = System.Drawing.Color.Black;
            this.Name_Label.Location = new System.Drawing.Point(404, 217);
            this.Name_Label.Name = "Name_Label";
            this.Name_Label.Size = new System.Drawing.Size(64, 28);
            this.Name_Label.TabIndex = 15;
            this.Name_Label.Text = "name";
            // 
            // id_label
            // 
            this.id_label.AutoSize = true;
            this.id_label.BackColor = System.Drawing.Color.Silver;
            this.id_label.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.id_label.ForeColor = System.Drawing.Color.Black;
            this.id_label.Location = new System.Drawing.Point(404, 181);
            this.id_label.Name = "id_label";
            this.id_label.Size = new System.Drawing.Size(30, 28);
            this.id_label.TabIndex = 14;
            this.id_label.Text = "id";
            // 
            // Instructor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1045, 656);
            this.Controls.Add(this.email_lable);
            this.Controls.Add(this.Gender_label);
            this.Controls.Add(this.Phone_Lable);
            this.Controls.Add(this.dob_lable);
            this.Controls.Add(this.Ciy_Lable);
            this.Controls.Add(this.Salary_lable);
            this.Controls.Add(this.Name_Label);
            this.Controls.Add(this.id_label);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.addtopicbtn);
            this.Controls.Add(this.topbame_txt);
            this.Controls.Add(this.TopName_lab);
            this.Controls.Add(this.crshours_txt);
            this.Controls.Add(this.crsHours_lab);
            this.Controls.Add(this.addcrsbtndet);
            this.Controls.Add(this.crsname_txt);
            this.Controls.Add(this.crsidaddcourse_txt);
            this.Controls.Add(this.crs_name_addcrs_lable);
            this.Controls.Add(this.crs_id_addcrs_lable);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.panel1);
            this.MaximizeBox = false;
            this.Name = "Instructor";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Instructor";
            this.Load += new System.EventHandler(this.Instructor_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Panel panel1;
        private Button button1;
        private PictureBox pictureBox1;
        private PictureBox pictureBox2;
        private Button AddCoursebtn;
        private Button AddTopicsbtn;
        private Label label1;
        private Label crs_id_addcrs_lable;
        private Label crs_name_addcrs_lable;
        private TextBox crsidaddcourse_txt;
        private TextBox crsname_txt;
        private Button addcrsbtndet;
        private TextBox crshours_txt;
        private Label crsHours_lab;
        private Label TopName_lab;
        private TextBox topbame_txt;
        private Button addtopicbtn;
        private DataGridView dataGridView1;
        private Button insinfo_btn;
        private Label email_lable;
        private Label Gender_label;
        private Label Phone_Lable;
        private Label dob_lable;
        private Label Ciy_Lable;
        private Label Salary_lable;
        private Label Name_Label;
        private Label id_label;
    }
}