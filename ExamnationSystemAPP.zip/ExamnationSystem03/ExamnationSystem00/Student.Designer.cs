﻿namespace ExamnationSystem00
{
    partial class Student
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.infobt = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Exambtn = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.choosecourse = new System.Windows.Forms.Label();
            this.StartExam = new System.Windows.Forms.Button();
            this.crs5 = new System.Windows.Forms.RadioButton();
            this.crs4 = new System.Windows.Forms.RadioButton();
            this.crs3 = new System.Windows.Forms.RadioButton();
            this.crs2 = new System.Windows.Forms.RadioButton();
            this.crs1 = new System.Windows.Forms.RadioButton();
            this.email_lable = new System.Windows.Forms.Label();
            this.Gender_label = new System.Windows.Forms.Label();
            this.Phone_Lable = new System.Windows.Forms.Label();
            this.dob_lable = new System.Windows.Forms.Label();
            this.Ciy_Lable = new System.Windows.Forms.Label();
            this.Faculty_lable = new System.Windows.Forms.Label();
            this.Name_Label = new System.Windows.Forms.Label();
            this.id_label = new System.Windows.Forms.Label();
            this.dataGridViewGrades = new System.Windows.Forms.DataGridView();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewGrades)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.infobt);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.Exambtn);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(250, 656);
            this.panel1.TabIndex = 0;
            // 
            // infobt
            // 
            this.infobt.BackColor = System.Drawing.Color.LightCoral;
            this.infobt.Cursor = System.Windows.Forms.Cursors.Hand;
            this.infobt.FlatAppearance.BorderSize = 0;
            this.infobt.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.infobt.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.infobt.ForeColor = System.Drawing.Color.White;
            this.infobt.Location = new System.Drawing.Point(0, 258);
            this.infobt.Name = "infobt";
            this.infobt.Size = new System.Drawing.Size(251, 34);
            this.infobt.TabIndex = 4;
            this.infobt.Text = "My information";
            this.infobt.UseVisualStyleBackColor = false;
            this.infobt.Click += new System.EventHandler(this.infobt_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(47, 202);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(50, 20);
            this.label2.TabIndex = 3;
            this.label2.Text = "label2";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(60, 165);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(50, 20);
            this.label1.TabIndex = 2;
            this.label1.Text = "label1";
            // 
            // Exambtn
            // 
            this.Exambtn.BackColor = System.Drawing.Color.LightCoral;
            this.Exambtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Exambtn.FlatAppearance.BorderSize = 0;
            this.Exambtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Exambtn.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Exambtn.ForeColor = System.Drawing.Color.White;
            this.Exambtn.Location = new System.Drawing.Point(0, 340);
            this.Exambtn.Name = "Exambtn";
            this.Exambtn.Size = new System.Drawing.Size(250, 34);
            this.Exambtn.TabIndex = 2;
            this.Exambtn.Text = "Exams";
            this.Exambtn.UseVisualStyleBackColor = false;
            this.Exambtn.Click += new System.EventHandler(this.Exambtn_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.LightCoral;
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(0, 299);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(251, 34);
            this.button1.TabIndex = 1;
            this.button1.Text = "Grades";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::ExamnationSystem00.Properties.Resources.iti_logo_5b9a0fd125be_300x133;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(250, 114);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Controls.Add(this.StartExam);
            this.panel2.Controls.Add(this.crs5);
            this.panel2.Controls.Add(this.crs4);
            this.panel2.Controls.Add(this.crs3);
            this.panel2.Controls.Add(this.crs2);
            this.panel2.Controls.Add(this.crs1);
            this.panel2.Controls.Add(this.email_lable);
            this.panel2.Controls.Add(this.Gender_label);
            this.panel2.Controls.Add(this.Phone_Lable);
            this.panel2.Controls.Add(this.dob_lable);
            this.panel2.Controls.Add(this.Ciy_Lable);
            this.panel2.Controls.Add(this.Faculty_lable);
            this.panel2.Controls.Add(this.Name_Label);
            this.panel2.Controls.Add(this.id_label);
            this.panel2.Controls.Add(this.dataGridViewGrades);
            this.panel2.Controls.Add(this.pictureBox2);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(250, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(795, 656);
            this.panel2.TabIndex = 1;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.LightCoral;
            this.panel3.Controls.Add(this.choosecourse);
            this.panel3.Location = new System.Drawing.Point(0, 17);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(795, 56);
            this.panel3.TabIndex = 5;
            // 
            // choosecourse
            // 
            this.choosecourse.AutoSize = true;
            this.choosecourse.BackColor = System.Drawing.Color.LightCoral;
            this.choosecourse.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.choosecourse.ForeColor = System.Drawing.Color.White;
            this.choosecourse.Location = new System.Drawing.Point(291, 12);
            this.choosecourse.Name = "choosecourse";
            this.choosecourse.Size = new System.Drawing.Size(190, 32);
            this.choosecourse.TabIndex = 17;
            this.choosecourse.Text = "Choose Course ";
            // 
            // StartExam
            // 
            this.StartExam.BackColor = System.Drawing.Color.LightCoral;
            this.StartExam.Cursor = System.Windows.Forms.Cursors.Hand;
            this.StartExam.FlatAppearance.BorderSize = 0;
            this.StartExam.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.StartExam.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.StartExam.ForeColor = System.Drawing.Color.White;
            this.StartExam.Location = new System.Drawing.Point(313, 380);
            this.StartExam.Name = "StartExam";
            this.StartExam.Size = new System.Drawing.Size(124, 38);
            this.StartExam.TabIndex = 5;
            this.StartExam.Text = "Start Exam";
            this.StartExam.UseVisualStyleBackColor = false;
            this.StartExam.Click += new System.EventHandler(this.StartExam_Click);
            // 
            // crs5
            // 
            this.crs5.AutoSize = true;
            this.crs5.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.crs5.ForeColor = System.Drawing.Color.Black;
            this.crs5.Location = new System.Drawing.Point(313, 341);
            this.crs5.Name = "crs5";
            this.crs5.Size = new System.Drawing.Size(124, 24);
            this.crs5.TabIndex = 16;
            this.crs5.TabStop = true;
            this.crs5.Text = "radioButton5";
            this.crs5.UseVisualStyleBackColor = true;
            // 
            // crs4
            // 
            this.crs4.AutoSize = true;
            this.crs4.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.crs4.ForeColor = System.Drawing.Color.Black;
            this.crs4.Location = new System.Drawing.Point(313, 306);
            this.crs4.Name = "crs4";
            this.crs4.Size = new System.Drawing.Size(124, 24);
            this.crs4.TabIndex = 15;
            this.crs4.TabStop = true;
            this.crs4.Text = "radioButton4";
            this.crs4.UseVisualStyleBackColor = true;
            // 
            // crs3
            // 
            this.crs3.AutoSize = true;
            this.crs3.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.crs3.ForeColor = System.Drawing.Color.Black;
            this.crs3.Location = new System.Drawing.Point(313, 271);
            this.crs3.Name = "crs3";
            this.crs3.Size = new System.Drawing.Size(124, 24);
            this.crs3.TabIndex = 14;
            this.crs3.TabStop = true;
            this.crs3.Text = "radioButton3";
            this.crs3.UseVisualStyleBackColor = true;
            // 
            // crs2
            // 
            this.crs2.AutoSize = true;
            this.crs2.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.crs2.ForeColor = System.Drawing.Color.Black;
            this.crs2.Location = new System.Drawing.Point(313, 236);
            this.crs2.Name = "crs2";
            this.crs2.Size = new System.Drawing.Size(124, 24);
            this.crs2.TabIndex = 13;
            this.crs2.TabStop = true;
            this.crs2.Text = "radioButton2";
            this.crs2.UseVisualStyleBackColor = true;
            // 
            // crs1
            // 
            this.crs1.AutoSize = true;
            this.crs1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.crs1.ForeColor = System.Drawing.Color.Black;
            this.crs1.Location = new System.Drawing.Point(313, 201);
            this.crs1.Name = "crs1";
            this.crs1.Size = new System.Drawing.Size(124, 24);
            this.crs1.TabIndex = 5;
            this.crs1.TabStop = true;
            this.crs1.Text = "radioButton1";
            this.crs1.UseVisualStyleBackColor = true;
            // 
            // email_lable
            // 
            this.email_lable.AutoSize = true;
            this.email_lable.BackColor = System.Drawing.Color.LightCoral;
            this.email_lable.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.email_lable.ForeColor = System.Drawing.Color.White;
            this.email_lable.Location = new System.Drawing.Point(81, 257);
            this.email_lable.Name = "email_lable";
            this.email_lable.Size = new System.Drawing.Size(64, 28);
            this.email_lable.TabIndex = 12;
            this.email_lable.Text = "email";
            // 
            // Gender_label
            // 
            this.Gender_label.AutoSize = true;
            this.Gender_label.BackColor = System.Drawing.Color.LightCoral;
            this.Gender_label.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Gender_label.ForeColor = System.Drawing.Color.White;
            this.Gender_label.Location = new System.Drawing.Point(81, 365);
            this.Gender_label.Name = "Gender_label";
            this.Gender_label.Size = new System.Drawing.Size(78, 28);
            this.Gender_label.TabIndex = 11;
            this.Gender_label.Text = "gender";
            // 
            // Phone_Lable
            // 
            this.Phone_Lable.AutoSize = true;
            this.Phone_Lable.BackColor = System.Drawing.Color.LightCoral;
            this.Phone_Lable.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Phone_Lable.ForeColor = System.Drawing.Color.White;
            this.Phone_Lable.Location = new System.Drawing.Point(81, 437);
            this.Phone_Lable.Name = "Phone_Lable";
            this.Phone_Lable.Size = new System.Drawing.Size(71, 28);
            this.Phone_Lable.TabIndex = 10;
            this.Phone_Lable.Text = "phone";
            // 
            // dob_lable
            // 
            this.dob_lable.AutoSize = true;
            this.dob_lable.BackColor = System.Drawing.Color.LightCoral;
            this.dob_lable.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.dob_lable.ForeColor = System.Drawing.Color.White;
            this.dob_lable.Location = new System.Drawing.Point(81, 401);
            this.dob_lable.Name = "dob_lable";
            this.dob_lable.Size = new System.Drawing.Size(48, 28);
            this.dob_lable.TabIndex = 9;
            this.dob_lable.Text = "dob";
            // 
            // Ciy_Lable
            // 
            this.Ciy_Lable.AutoSize = true;
            this.Ciy_Lable.BackColor = System.Drawing.Color.LightCoral;
            this.Ciy_Lable.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Ciy_Lable.ForeColor = System.Drawing.Color.White;
            this.Ciy_Lable.Location = new System.Drawing.Point(81, 329);
            this.Ciy_Lable.Name = "Ciy_Lable";
            this.Ciy_Lable.Size = new System.Drawing.Size(47, 28);
            this.Ciy_Lable.TabIndex = 8;
            this.Ciy_Lable.Text = "city";
            // 
            // Faculty_lable
            // 
            this.Faculty_lable.AutoSize = true;
            this.Faculty_lable.BackColor = System.Drawing.Color.LightCoral;
            this.Faculty_lable.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Faculty_lable.ForeColor = System.Drawing.Color.White;
            this.Faculty_lable.Location = new System.Drawing.Point(81, 293);
            this.Faculty_lable.Name = "Faculty_lable";
            this.Faculty_lable.Size = new System.Drawing.Size(78, 28);
            this.Faculty_lable.TabIndex = 7;
            this.Faculty_lable.Text = "faculty";
            // 
            // Name_Label
            // 
            this.Name_Label.AutoSize = true;
            this.Name_Label.BackColor = System.Drawing.Color.LightCoral;
            this.Name_Label.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Name_Label.ForeColor = System.Drawing.Color.White;
            this.Name_Label.Location = new System.Drawing.Point(81, 221);
            this.Name_Label.Name = "Name_Label";
            this.Name_Label.Size = new System.Drawing.Size(64, 28);
            this.Name_Label.TabIndex = 6;
            this.Name_Label.Text = "name";
            // 
            // id_label
            // 
            this.id_label.AutoSize = true;
            this.id_label.BackColor = System.Drawing.Color.LightCoral;
            this.id_label.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.id_label.ForeColor = System.Drawing.Color.White;
            this.id_label.Location = new System.Drawing.Point(81, 185);
            this.id_label.Name = "id_label";
            this.id_label.Size = new System.Drawing.Size(30, 28);
            this.id_label.TabIndex = 5;
            this.id_label.Text = "id";
            // 
            // dataGridViewGrades
            // 
            this.dataGridViewGrades.BackgroundColor = System.Drawing.Color.White;
            this.dataGridViewGrades.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridViewGrades.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.LightCoral;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.LightCoral;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewGrades.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridViewGrades.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.LightCoral;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.LightCoral;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewGrades.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridViewGrades.GridColor = System.Drawing.Color.White;
            this.dataGridViewGrades.Location = new System.Drawing.Point(151, 201);
            this.dataGridViewGrades.Name = "dataGridViewGrades";
            this.dataGridViewGrades.RowHeadersWidth = 51;
            this.dataGridViewGrades.RowTemplate.Height = 29;
            this.dataGridViewGrades.Size = new System.Drawing.Size(439, 201);
            this.dataGridViewGrades.TabIndex = 3;
            this.dataGridViewGrades.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewGrades_CellContentClick);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::ExamnationSystem00.Properties.Resources.Students_watching_webinar_on_computer;
            this.pictureBox2.Location = new System.Drawing.Point(-13, 0);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(823, 656);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 0;
            this.pictureBox2.TabStop = false;
            // 
            // Student
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1045, 656);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.MaximizeBox = false;
            this.Name = "Student";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Student";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewGrades)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Panel panel1;
        private Button button1;
        private PictureBox pictureBox1;
        private Button Exambtn;
        private Panel panel2;
        private PictureBox pictureBox2;
        private Label label1;
        private DataGridView dataGridViewGrades;
        private Label label2;
        private Button infobt;
        private Label Phone_Lable;
        private Label dob_lable;
        private Label Ciy_Lable;
        private Label Faculty_lable;
        private Label Name_Label;
        private Label id_label;
        private Label email_lable;
        private Label Gender_label;
        private RadioButton crs5;
        private RadioButton crs4;
        private RadioButton crs3;
        private RadioButton crs2;
        private RadioButton crs1;
        private Button StartExam;
        private Label choosecourse;
        private Panel panel3;
    }
}