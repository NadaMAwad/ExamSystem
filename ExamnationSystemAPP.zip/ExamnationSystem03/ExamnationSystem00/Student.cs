﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ExamnationSystem00.Models;
using Microsoft.EntityFrameworkCore.Migrations;
using static System.Formats.Asn1.AsnWriter;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
using Microsoft.Data.SqlClient;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using System.Reflection.Emit;
using static System.ComponentModel.Design.ObjectSelectorEditor;
using System.Runtime.Intrinsics.X86;

namespace ExamnationSystem00
{
    public partial class Student : Form
    {
        ExamDB ExamSys = new ExamDB();
       public int id;
        public string name;

      
        public Student(int _id,string _name)
        {
            InitializeComponent();
            panel3.Visible = false;
            dataGridViewGrades.Visible = false;
            id_label.Visible = false;
            Name_Label.Visible = false;
            Faculty_lable.Visible = false;
            dob_lable.Visible = false;
            Ciy_Lable.Visible = false;
            Phone_Lable.Visible = false;
            email_lable.Visible = false;
            Gender_label.Visible = false;
            choosecourse.Visible = false;
            crs1.Visible = false;
            crs2.Visible = false;
            crs3.Visible = false;
            crs4.Visible = false;
            crs5.Visible = false;
            StartExam.Visible = false;
            id = _id;
            name = _name;
            Students S = ExamSys.Students.FirstOrDefault(x => x.Ssn ==id);
            Departments dept = ExamSys.Departments.FirstOrDefault(x => x.DeptId == S.DeptId);
            label1.Text = "Hello " + _name + "!";
            label2.Text = "Your Department is: " + dept.DeptName ;


        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private async void button1_Click(object sender, EventArgs e)
        {
            pictureBox2.Visible = false;
            panel3.Visible = false;

            dataGridViewGrades.Visible = true;
            id_label.Visible = false;
            Name_Label.Visible = false;
            Faculty_lable.Visible = false;
            dob_lable.Visible = false;
            Ciy_Lable.Visible = false;
            Phone_Lable.Visible = false;
            email_lable.Visible = false;
            Gender_label.Visible = false;
            choosecourse.Visible = false;
            crs1.Visible = false;
            crs2.Visible = false;
            crs3.Visible = false;
            crs4.Visible = false;
            crs5.Visible = false;
            StartExam.Visible = false;

            //dataGridViewGrades.DataSource = ExamSys.Procedures.StudenResultsAsync(1062);

            var param = new SqlParameter[] {
                                    new SqlParameter() {
                                        ParameterName = "@StID",
                                        SqlDbType =  System.Data.SqlDbType.Int,
                                        Size = 100,
                                        Direction = System.Data.ParameterDirection.Input,
                                        Value = id
                                    },
                                   };
                        List<Grades> studentList = ExamSys.Grades.FromSqlRaw("[dbo].[Gradess] @StID", param).ToList();
                  
                        dataGridViewGrades.DataSource = studentList;
            

        }

        private void infobt_Click(object sender, EventArgs e)
        {

            Students S = ExamSys.Students.FirstOrDefault(x => x.Ssn == id);
            panel3.Visible = false;

            pictureBox2.Visible = false;
            dataGridViewGrades.Visible = false;
            id_label.Visible = true;
            Name_Label.Visible = true;
            Faculty_lable.Visible = true;
            dob_lable.Visible = true;
            Ciy_Lable.Visible = true;
            Phone_Lable.Visible =true;
            email_lable.Visible = true;
            Gender_label.Visible = true;
            choosecourse.Visible = false;
            crs1.Visible = false;
            crs2.Visible = false;
            crs3.Visible = false;
            crs4.Visible = false;
            crs5.Visible = false;
            StartExam.Visible = false;

            id_label.Text = "ID: " + id;
            Name_Label.Text = "Name: " + name;
            Faculty_lable.Text = "Fculty: " + S.Faculty;
            Ciy_Lable.Text = "City: " + S.City;
            dob_lable.Text = "Date of birth: " + S.Dob;
            Phone_Lable.Text = "Phone Number: " + S.PhoneNumber;
            Gender_label.Text = "Gender: " + S.Gender;
            email_lable.Text = "E-mail: " + S.Email;


        }

        private void Exambtn_Click(object sender, EventArgs e)
        {
            pictureBox2.Visible = false;
            dataGridViewGrades.Visible = false;
            id_label.Visible = false;
            Name_Label.Visible = false;
            Faculty_lable.Visible = false;
            dob_lable.Visible = false;
            Ciy_Lable.Visible = false;
            Phone_Lable.Visible = false;
            email_lable.Visible = false;
            Gender_label.Visible = false;
            choosecourse.Visible = true;
            StartExam.Visible = true;
            panel3.Visible = true;

            Students S = ExamSys.Students.FirstOrDefault(x => x.Ssn == id);
            if (S.DeptId == 100)
            {
                crs1.Visible = true;
                crs2.Visible = true;
                crs3.Visible = true;
                crs4.Visible = true;
                crs5.Visible = true;


                crs1.Text = "Excel"; //1
                crs2.Text = "C#"; //2
                crs3.Text = "SQL"; //3
                crs4.Text = "Power Bi";  //4
                crs5.Text = "Data Structure"; //6



            }
            else if (S.DeptId == 200)
            {
                crs1.Visible = true;
                crs3.Visible = true;
                crs5.Visible = true;

                crs1.Text = "C#"; //2
                crs3.Text = "SQL"; //3
                crs5.Text = "Power Bi"; //4
            }
            else if (S.DeptId == 300)
            {
                crs1.Visible = true;
                crs2.Visible = true;
                crs3.Visible = true;
                crs4.Visible = true;

                crs1.Text = "C#"; //2
                crs2.Text = "SQL"; //3
                crs3.Text = "Power Bi"; //4
                crs4.Text = "Data Structure";  //6
            }
            else
            {
                crs1.Visible = true;
                crs3.Visible = true;

                crs1.Text = "SQL"; //3
                crs3.Text = "Cloud"; //5
               

            }
        
    }

        private void StartExam_Click(object sender, EventArgs e)
        {
            int crs_id =0;
            if (crs1.Checked)
            {
                Courses crs = ExamSys.Courses.FirstOrDefault(x => x.CrsName == crs1.Text);
                crs_id = crs.CrsId;
            }
            else if (crs2.Checked)
            {
                Courses crs = ExamSys.Courses.FirstOrDefault(x => x.CrsName == crs2.Text);
                crs_id = crs.CrsId;
            }
            else if (crs3.Checked)
            {
                Courses crs = ExamSys.Courses.FirstOrDefault(x => x.CrsName == crs3.Text);
                crs_id = crs.CrsId;
            }
            else if (crs4.Checked)
            {
                Courses crs = ExamSys.Courses.FirstOrDefault(x => x.CrsName == crs4.Text);
                crs_id = crs.CrsId;
            }
            else if (crs5.Checked)
            {
                Courses crs = ExamSys.Courses.FirstOrDefault(x => x.CrsName == crs5.Text);
                crs_id = crs.CrsId;
            }
            else
            {
                MessageBox.Show("Please Select Course");
            }

          // this.Visible = true;
           Exam E = new Exam(crs_id,id);
           E.ShowDialog();
        }

        private void dataGridViewGrades_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
