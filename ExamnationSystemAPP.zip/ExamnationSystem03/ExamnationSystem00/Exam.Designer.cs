﻿namespace ExamnationSystem00
{
    partial class Exam
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.q1 = new System.Windows.Forms.Label();
            this.r1_1 = new System.Windows.Forms.RadioButton();
            this.r1_2 = new System.Windows.Forms.RadioButton();
            this.r1_3 = new System.Windows.Forms.RadioButton();
            this.r1_4 = new System.Windows.Forms.RadioButton();
            this.r2_4 = new System.Windows.Forms.RadioButton();
            this.r2_3 = new System.Windows.Forms.RadioButton();
            this.r2_2 = new System.Windows.Forms.RadioButton();
            this.r2_1 = new System.Windows.Forms.RadioButton();
            this.q2 = new System.Windows.Forms.Label();
            this.r4_4 = new System.Windows.Forms.RadioButton();
            this.r4_3 = new System.Windows.Forms.RadioButton();
            this.r4_2 = new System.Windows.Forms.RadioButton();
            this.r4_1 = new System.Windows.Forms.RadioButton();
            this.q4 = new System.Windows.Forms.Label();
            this.r3_4 = new System.Windows.Forms.RadioButton();
            this.r3_3 = new System.Windows.Forms.RadioButton();
            this.r3_2 = new System.Windows.Forms.RadioButton();
            this.r3_1 = new System.Windows.Forms.RadioButton();
            this.q3 = new System.Windows.Forms.Label();
            this.r6_4 = new System.Windows.Forms.RadioButton();
            this.r6_3 = new System.Windows.Forms.RadioButton();
            this.r6_2 = new System.Windows.Forms.RadioButton();
            this.r6_1 = new System.Windows.Forms.RadioButton();
            this.q6 = new System.Windows.Forms.Label();
            this.r5_4 = new System.Windows.Forms.RadioButton();
            this.r5_3 = new System.Windows.Forms.RadioButton();
            this.r5_2 = new System.Windows.Forms.RadioButton();
            this.r5_1 = new System.Windows.Forms.RadioButton();
            this.q5 = new System.Windows.Forms.Label();
            this.r10_2 = new System.Windows.Forms.RadioButton();
            this.r10_1 = new System.Windows.Forms.RadioButton();
            this.q10 = new System.Windows.Forms.Label();
            this.r8_4 = new System.Windows.Forms.RadioButton();
            this.r9_2 = new System.Windows.Forms.RadioButton();
            this.r9_1 = new System.Windows.Forms.RadioButton();
            this.q9 = new System.Windows.Forms.Label();
            this.r8_3 = new System.Windows.Forms.RadioButton();
            this.r8_2 = new System.Windows.Forms.RadioButton();
            this.r8_1 = new System.Windows.Forms.RadioButton();
            this.q8 = new System.Windows.Forms.Label();
            this.r7_4 = new System.Windows.Forms.RadioButton();
            this.r7_3 = new System.Windows.Forms.RadioButton();
            this.r7_2 = new System.Windows.Forms.RadioButton();
            this.r7_1 = new System.Windows.Forms.RadioButton();
            this.q7 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.panel10 = new System.Windows.Forms.Panel();
            this.Finish_btn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel10.SuspendLayout();
            this.SuspendLayout();
            // 
            // q1
            // 
            this.q1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.q1.AutoSize = true;
            this.q1.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.q1.Location = new System.Drawing.Point(24, 96);
            this.q1.Name = "q1";
            this.q1.Size = new System.Drawing.Size(59, 23);
            this.q1.TabIndex = 0;
            this.q1.Text = "label1";
            this.q1.Click += new System.EventHandler(this.q1_Click);
            // 
            // r1_1
            // 
            this.r1_1.AutoSize = true;
            this.r1_1.Location = new System.Drawing.Point(3, 1);
            this.r1_1.Name = "r1_1";
            this.r1_1.Size = new System.Drawing.Size(117, 24);
            this.r1_1.TabIndex = 1;
            this.r1_1.TabStop = true;
            this.r1_1.Text = "radioButton1";
            this.r1_1.UseVisualStyleBackColor = true;
            // 
            // r1_2
            // 
            this.r1_2.AutoSize = true;
            this.r1_2.Location = new System.Drawing.Point(3, 31);
            this.r1_2.Name = "r1_2";
            this.r1_2.Size = new System.Drawing.Size(117, 24);
            this.r1_2.TabIndex = 2;
            this.r1_2.TabStop = true;
            this.r1_2.Text = "radioButton2";
            this.r1_2.UseVisualStyleBackColor = true;
            // 
            // r1_3
            // 
            this.r1_3.AutoSize = true;
            this.r1_3.Location = new System.Drawing.Point(3, 61);
            this.r1_3.Name = "r1_3";
            this.r1_3.Size = new System.Drawing.Size(117, 24);
            this.r1_3.TabIndex = 3;
            this.r1_3.TabStop = true;
            this.r1_3.Text = "radioButton3";
            this.r1_3.UseVisualStyleBackColor = true;
            // 
            // r1_4
            // 
            this.r1_4.AutoSize = true;
            this.r1_4.Location = new System.Drawing.Point(3, 91);
            this.r1_4.Name = "r1_4";
            this.r1_4.Size = new System.Drawing.Size(117, 24);
            this.r1_4.TabIndex = 4;
            this.r1_4.TabStop = true;
            this.r1_4.Text = "radioButton4";
            this.r1_4.UseVisualStyleBackColor = true;
            // 
            // r2_4
            // 
            this.r2_4.AutoSize = true;
            this.r2_4.Location = new System.Drawing.Point(5, 93);
            this.r2_4.Name = "r2_4";
            this.r2_4.Size = new System.Drawing.Size(117, 24);
            this.r2_4.TabIndex = 9;
            this.r2_4.TabStop = true;
            this.r2_4.Text = "radioButton5";
            this.r2_4.UseVisualStyleBackColor = true;
            // 
            // r2_3
            // 
            this.r2_3.AutoSize = true;
            this.r2_3.Location = new System.Drawing.Point(5, 63);
            this.r2_3.Name = "r2_3";
            this.r2_3.Size = new System.Drawing.Size(117, 24);
            this.r2_3.TabIndex = 8;
            this.r2_3.TabStop = true;
            this.r2_3.Text = "radioButton6";
            this.r2_3.UseVisualStyleBackColor = true;
            // 
            // r2_2
            // 
            this.r2_2.AutoSize = true;
            this.r2_2.Location = new System.Drawing.Point(5, 33);
            this.r2_2.Name = "r2_2";
            this.r2_2.Size = new System.Drawing.Size(117, 24);
            this.r2_2.TabIndex = 7;
            this.r2_2.TabStop = true;
            this.r2_2.Text = "radioButton7";
            this.r2_2.UseVisualStyleBackColor = true;
            // 
            // r2_1
            // 
            this.r2_1.AutoSize = true;
            this.r2_1.Location = new System.Drawing.Point(5, 9);
            this.r2_1.Name = "r2_1";
            this.r2_1.Size = new System.Drawing.Size(117, 24);
            this.r2_1.TabIndex = 6;
            this.r2_1.TabStop = true;
            this.r2_1.Text = "radioButton8";
            this.r2_1.UseVisualStyleBackColor = true;
            // 
            // q2
            // 
            this.q2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.q2.AutoSize = true;
            this.q2.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.q2.Location = new System.Drawing.Point(24, 246);
            this.q2.Name = "q2";
            this.q2.Size = new System.Drawing.Size(59, 23);
            this.q2.TabIndex = 5;
            this.q2.Text = "label2";
            // 
            // r4_4
            // 
            this.r4_4.AutoSize = true;
            this.r4_4.Location = new System.Drawing.Point(3, 97);
            this.r4_4.Name = "r4_4";
            this.r4_4.Size = new System.Drawing.Size(117, 24);
            this.r4_4.TabIndex = 19;
            this.r4_4.TabStop = true;
            this.r4_4.Text = "radioButton9";
            this.r4_4.UseVisualStyleBackColor = true;
            // 
            // r4_3
            // 
            this.r4_3.AutoSize = true;
            this.r4_3.Location = new System.Drawing.Point(3, 67);
            this.r4_3.Name = "r4_3";
            this.r4_3.Size = new System.Drawing.Size(125, 24);
            this.r4_3.TabIndex = 18;
            this.r4_3.TabStop = true;
            this.r4_3.Text = "radioButton10";
            this.r4_3.UseVisualStyleBackColor = true;
            // 
            // r4_2
            // 
            this.r4_2.AutoSize = true;
            this.r4_2.Location = new System.Drawing.Point(3, 37);
            this.r4_2.Name = "r4_2";
            this.r4_2.Size = new System.Drawing.Size(125, 24);
            this.r4_2.TabIndex = 17;
            this.r4_2.TabStop = true;
            this.r4_2.Text = "radioButton11";
            this.r4_2.UseVisualStyleBackColor = true;
            // 
            // r4_1
            // 
            this.r4_1.AutoSize = true;
            this.r4_1.Location = new System.Drawing.Point(3, 7);
            this.r4_1.Name = "r4_1";
            this.r4_1.Size = new System.Drawing.Size(125, 24);
            this.r4_1.TabIndex = 16;
            this.r4_1.TabStop = true;
            this.r4_1.Text = "radioButton12";
            this.r4_1.UseVisualStyleBackColor = true;
            // 
            // q4
            // 
            this.q4.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.q4.AutoSize = true;
            this.q4.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.q4.Location = new System.Drawing.Point(24, 556);
            this.q4.Name = "q4";
            this.q4.Size = new System.Drawing.Size(59, 23);
            this.q4.TabIndex = 15;
            this.q4.Text = "label3";
            // 
            // r3_4
            // 
            this.r3_4.AutoSize = true;
            this.r3_4.Location = new System.Drawing.Point(3, 98);
            this.r3_4.Name = "r3_4";
            this.r3_4.Size = new System.Drawing.Size(125, 24);
            this.r3_4.TabIndex = 14;
            this.r3_4.TabStop = true;
            this.r3_4.Text = "radioButton13";
            this.r3_4.UseVisualStyleBackColor = true;
            // 
            // r3_3
            // 
            this.r3_3.AutoSize = true;
            this.r3_3.Location = new System.Drawing.Point(3, 68);
            this.r3_3.Name = "r3_3";
            this.r3_3.Size = new System.Drawing.Size(125, 24);
            this.r3_3.TabIndex = 13;
            this.r3_3.TabStop = true;
            this.r3_3.Text = "radioButton14";
            this.r3_3.UseVisualStyleBackColor = true;
            // 
            // r3_2
            // 
            this.r3_2.AutoSize = true;
            this.r3_2.Location = new System.Drawing.Point(3, 38);
            this.r3_2.Name = "r3_2";
            this.r3_2.Size = new System.Drawing.Size(125, 24);
            this.r3_2.TabIndex = 12;
            this.r3_2.TabStop = true;
            this.r3_2.Text = "radioButton15";
            this.r3_2.UseVisualStyleBackColor = true;
            // 
            // r3_1
            // 
            this.r3_1.AutoSize = true;
            this.r3_1.Location = new System.Drawing.Point(3, 8);
            this.r3_1.Name = "r3_1";
            this.r3_1.Size = new System.Drawing.Size(125, 24);
            this.r3_1.TabIndex = 11;
            this.r3_1.TabStop = true;
            this.r3_1.Text = "radioButton16";
            this.r3_1.UseVisualStyleBackColor = true;
            // 
            // q3
            // 
            this.q3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.q3.AutoSize = true;
            this.q3.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.q3.Location = new System.Drawing.Point(24, 399);
            this.q3.Name = "q3";
            this.q3.Size = new System.Drawing.Size(59, 23);
            this.q3.TabIndex = 10;
            this.q3.Text = "label4";
            // 
            // r6_4
            // 
            this.r6_4.AutoSize = true;
            this.r6_4.Location = new System.Drawing.Point(3, 91);
            this.r6_4.Name = "r6_4";
            this.r6_4.Size = new System.Drawing.Size(125, 24);
            this.r6_4.TabIndex = 29;
            this.r6_4.TabStop = true;
            this.r6_4.Text = "radioButton17";
            this.r6_4.UseVisualStyleBackColor = true;
            // 
            // r6_3
            // 
            this.r6_3.AutoSize = true;
            this.r6_3.Location = new System.Drawing.Point(3, 61);
            this.r6_3.Name = "r6_3";
            this.r6_3.Size = new System.Drawing.Size(125, 24);
            this.r6_3.TabIndex = 28;
            this.r6_3.TabStop = true;
            this.r6_3.Text = "radioButton18";
            this.r6_3.UseVisualStyleBackColor = true;
            // 
            // r6_2
            // 
            this.r6_2.AutoSize = true;
            this.r6_2.Location = new System.Drawing.Point(3, 31);
            this.r6_2.Name = "r6_2";
            this.r6_2.Size = new System.Drawing.Size(125, 24);
            this.r6_2.TabIndex = 27;
            this.r6_2.TabStop = true;
            this.r6_2.Text = "radioButton19";
            this.r6_2.UseVisualStyleBackColor = true;
            // 
            // r6_1
            // 
            this.r6_1.AutoSize = true;
            this.r6_1.Location = new System.Drawing.Point(3, 7);
            this.r6_1.Name = "r6_1";
            this.r6_1.Size = new System.Drawing.Size(125, 24);
            this.r6_1.TabIndex = 26;
            this.r6_1.TabStop = true;
            this.r6_1.Text = "radioButton20";
            this.r6_1.UseVisualStyleBackColor = true;
            // 
            // q6
            // 
            this.q6.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.q6.AutoSize = true;
            this.q6.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.q6.Location = new System.Drawing.Point(879, 98);
            this.q6.Name = "q6";
            this.q6.Size = new System.Drawing.Size(59, 23);
            this.q6.TabIndex = 25;
            this.q6.Text = "label5";
            // 
            // r5_4
            // 
            this.r5_4.AutoSize = true;
            this.r5_4.Location = new System.Drawing.Point(3, 95);
            this.r5_4.Name = "r5_4";
            this.r5_4.Size = new System.Drawing.Size(125, 24);
            this.r5_4.TabIndex = 24;
            this.r5_4.TabStop = true;
            this.r5_4.Text = "radioButton21";
            this.r5_4.UseVisualStyleBackColor = true;
            // 
            // r5_3
            // 
            this.r5_3.AutoSize = true;
            this.r5_3.Location = new System.Drawing.Point(3, 65);
            this.r5_3.Name = "r5_3";
            this.r5_3.Size = new System.Drawing.Size(125, 24);
            this.r5_3.TabIndex = 23;
            this.r5_3.TabStop = true;
            this.r5_3.Text = "radioButton22";
            this.r5_3.UseVisualStyleBackColor = true;
            // 
            // r5_2
            // 
            this.r5_2.AutoSize = true;
            this.r5_2.Location = new System.Drawing.Point(3, 35);
            this.r5_2.Name = "r5_2";
            this.r5_2.Size = new System.Drawing.Size(125, 24);
            this.r5_2.TabIndex = 22;
            this.r5_2.TabStop = true;
            this.r5_2.Text = "radioButton23";
            this.r5_2.UseVisualStyleBackColor = true;
            // 
            // r5_1
            // 
            this.r5_1.AutoSize = true;
            this.r5_1.Location = new System.Drawing.Point(3, 5);
            this.r5_1.Name = "r5_1";
            this.r5_1.Size = new System.Drawing.Size(125, 24);
            this.r5_1.TabIndex = 21;
            this.r5_1.TabStop = true;
            this.r5_1.Text = "radioButton24";
            this.r5_1.UseVisualStyleBackColor = true;
            // 
            // q5
            // 
            this.q5.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.q5.AutoSize = true;
            this.q5.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.q5.Location = new System.Drawing.Point(24, 705);
            this.q5.Name = "q5";
            this.q5.Size = new System.Drawing.Size(59, 23);
            this.q5.TabIndex = 20;
            this.q5.Text = "label6";
            // 
            // r10_2
            // 
            this.r10_2.AutoSize = true;
            this.r10_2.Location = new System.Drawing.Point(3, 35);
            this.r10_2.Name = "r10_2";
            this.r10_2.Size = new System.Drawing.Size(125, 24);
            this.r10_2.TabIndex = 47;
            this.r10_2.TabStop = true;
            this.r10_2.Text = "radioButton35";
            this.r10_2.UseVisualStyleBackColor = true;
            // 
            // r10_1
            // 
            this.r10_1.AutoSize = true;
            this.r10_1.Location = new System.Drawing.Point(3, 5);
            this.r10_1.Name = "r10_1";
            this.r10_1.Size = new System.Drawing.Size(125, 24);
            this.r10_1.TabIndex = 46;
            this.r10_1.TabStop = true;
            this.r10_1.Text = "radioButton36";
            this.r10_1.UseVisualStyleBackColor = true;
            // 
            // q10
            // 
            this.q10.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.q10.AutoSize = true;
            this.q10.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.q10.Location = new System.Drawing.Point(881, 703);
            this.q10.Name = "q10";
            this.q10.Size = new System.Drawing.Size(59, 23);
            this.q10.TabIndex = 45;
            this.q10.Text = "label9";
            // 
            // r8_4
            // 
            this.r8_4.AutoSize = true;
            this.r8_4.Location = new System.Drawing.Point(3, 98);
            this.r8_4.Name = "r8_4";
            this.r8_4.Size = new System.Drawing.Size(125, 24);
            this.r8_4.TabIndex = 44;
            this.r8_4.TabStop = true;
            this.r8_4.Text = "radioButton37";
            this.r8_4.UseVisualStyleBackColor = true;
            // 
            // r9_2
            // 
            this.r9_2.AutoSize = true;
            this.r9_2.Location = new System.Drawing.Point(7, 42);
            this.r9_2.Name = "r9_2";
            this.r9_2.Size = new System.Drawing.Size(125, 24);
            this.r9_2.TabIndex = 42;
            this.r9_2.TabStop = true;
            this.r9_2.Text = "radioButton39";
            this.r9_2.UseVisualStyleBackColor = true;
            // 
            // r9_1
            // 
            this.r9_1.AutoSize = true;
            this.r9_1.Location = new System.Drawing.Point(7, 12);
            this.r9_1.Name = "r9_1";
            this.r9_1.Size = new System.Drawing.Size(125, 24);
            this.r9_1.TabIndex = 41;
            this.r9_1.TabStop = true;
            this.r9_1.Text = "radioButton40";
            this.r9_1.UseVisualStyleBackColor = true;
            // 
            // q9
            // 
            this.q9.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.q9.AutoSize = true;
            this.q9.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.q9.Location = new System.Drawing.Point(879, 582);
            this.q9.Name = "q9";
            this.q9.Size = new System.Drawing.Size(69, 23);
            this.q9.TabIndex = 40;
            this.q9.Text = "label10";
            // 
            // r8_3
            // 
            this.r8_3.AutoSize = true;
            this.r8_3.Location = new System.Drawing.Point(3, 68);
            this.r8_3.Name = "r8_3";
            this.r8_3.Size = new System.Drawing.Size(125, 24);
            this.r8_3.TabIndex = 38;
            this.r8_3.TabStop = true;
            this.r8_3.Text = "radioButton42";
            this.r8_3.UseVisualStyleBackColor = true;
            // 
            // r8_2
            // 
            this.r8_2.AutoSize = true;
            this.r8_2.Location = new System.Drawing.Point(3, 38);
            this.r8_2.Name = "r8_2";
            this.r8_2.Size = new System.Drawing.Size(125, 24);
            this.r8_2.TabIndex = 37;
            this.r8_2.TabStop = true;
            this.r8_2.Text = "radioButton43";
            this.r8_2.UseVisualStyleBackColor = true;
            // 
            // r8_1
            // 
            this.r8_1.AutoSize = true;
            this.r8_1.Location = new System.Drawing.Point(3, 8);
            this.r8_1.Name = "r8_1";
            this.r8_1.Size = new System.Drawing.Size(125, 24);
            this.r8_1.TabIndex = 36;
            this.r8_1.TabStop = true;
            this.r8_1.Text = "radioButton44";
            this.r8_1.UseVisualStyleBackColor = true;
            // 
            // q8
            // 
            this.q8.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.q8.AutoSize = true;
            this.q8.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.q8.Location = new System.Drawing.Point(879, 401);
            this.q8.Name = "q8";
            this.q8.Size = new System.Drawing.Size(69, 23);
            this.q8.TabIndex = 35;
            this.q8.Text = "label11";
            // 
            // r7_4
            // 
            this.r7_4.AutoSize = true;
            this.r7_4.Location = new System.Drawing.Point(3, 98);
            this.r7_4.Name = "r7_4";
            this.r7_4.Size = new System.Drawing.Size(125, 24);
            this.r7_4.TabIndex = 34;
            this.r7_4.TabStop = true;
            this.r7_4.Text = "radioButton45";
            this.r7_4.UseVisualStyleBackColor = true;
            // 
            // r7_3
            // 
            this.r7_3.AutoSize = true;
            this.r7_3.Location = new System.Drawing.Point(3, 68);
            this.r7_3.Name = "r7_3";
            this.r7_3.Size = new System.Drawing.Size(125, 24);
            this.r7_3.TabIndex = 33;
            this.r7_3.TabStop = true;
            this.r7_3.Text = "radioButton46";
            this.r7_3.UseVisualStyleBackColor = true;
            // 
            // r7_2
            // 
            this.r7_2.AutoSize = true;
            this.r7_2.Location = new System.Drawing.Point(3, 38);
            this.r7_2.Name = "r7_2";
            this.r7_2.Size = new System.Drawing.Size(125, 24);
            this.r7_2.TabIndex = 32;
            this.r7_2.TabStop = true;
            this.r7_2.Text = "radioButton47";
            this.r7_2.UseVisualStyleBackColor = true;
            // 
            // r7_1
            // 
            this.r7_1.AutoSize = true;
            this.r7_1.Location = new System.Drawing.Point(3, 8);
            this.r7_1.Name = "r7_1";
            this.r7_1.Size = new System.Drawing.Size(125, 24);
            this.r7_1.TabIndex = 31;
            this.r7_1.TabStop = true;
            this.r7_1.Text = "radioButton48";
            this.r7_1.UseVisualStyleBackColor = true;
            // 
            // q7
            // 
            this.q7.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.q7.AutoSize = true;
            this.q7.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.q7.Location = new System.Drawing.Point(879, 245);
            this.q7.Name = "q7";
            this.q7.Size = new System.Drawing.Size(69, 23);
            this.q7.TabIndex = 30;
            this.q7.Text = "label12";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::ExamnationSystem00.Properties.Resources.iti_logo;
            this.pictureBox1.Location = new System.Drawing.Point(676, 8);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(59, 80);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 50;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Verdana", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.DarkRed;
            this.label1.Location = new System.Drawing.Point(774, 40);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(117, 36);
            this.label1.TabIndex = 51;
            this.label1.Text = "label1";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.r1_2);
            this.panel1.Controls.Add(this.r1_1);
            this.panel1.Controls.Add(this.r1_3);
            this.panel1.Controls.Add(this.r1_4);
            this.panel1.Location = new System.Drawing.Point(24, 119);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(773, 115);
            this.panel1.TabIndex = 52;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.r2_4);
            this.panel2.Controls.Add(this.r2_1);
            this.panel2.Controls.Add(this.r2_2);
            this.panel2.Controls.Add(this.r2_3);
            this.panel2.Location = new System.Drawing.Point(24, 269);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(773, 125);
            this.panel2.TabIndex = 53;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.r3_4);
            this.panel3.Controls.Add(this.r3_1);
            this.panel3.Controls.Add(this.r3_2);
            this.panel3.Controls.Add(this.r3_3);
            this.panel3.Location = new System.Drawing.Point(24, 424);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(773, 125);
            this.panel3.TabIndex = 54;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.r4_3);
            this.panel4.Controls.Add(this.r4_1);
            this.panel4.Controls.Add(this.r4_2);
            this.panel4.Controls.Add(this.r4_4);
            this.panel4.Location = new System.Drawing.Point(24, 577);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(773, 125);
            this.panel4.TabIndex = 55;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.r5_4);
            this.panel5.Controls.Add(this.r5_1);
            this.panel5.Controls.Add(this.r5_2);
            this.panel5.Controls.Add(this.r5_3);
            this.panel5.Location = new System.Drawing.Point(24, 728);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(773, 125);
            this.panel5.TabIndex = 56;
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.r6_4);
            this.panel6.Controls.Add(this.r6_1);
            this.panel6.Controls.Add(this.r6_2);
            this.panel6.Controls.Add(this.r6_3);
            this.panel6.Location = new System.Drawing.Point(879, 120);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(598, 114);
            this.panel6.TabIndex = 57;
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.r7_4);
            this.panel7.Controls.Add(this.r7_1);
            this.panel7.Controls.Add(this.r7_2);
            this.panel7.Controls.Add(this.r7_3);
            this.panel7.Location = new System.Drawing.Point(879, 269);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(598, 125);
            this.panel7.TabIndex = 58;
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.r8_4);
            this.panel8.Controls.Add(this.r8_1);
            this.panel8.Controls.Add(this.r8_2);
            this.panel8.Controls.Add(this.r8_3);
            this.panel8.Location = new System.Drawing.Point(879, 424);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(598, 125);
            this.panel8.TabIndex = 59;
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.r9_2);
            this.panel9.Controls.Add(this.r9_1);
            this.panel9.Location = new System.Drawing.Point(879, 603);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(598, 96);
            this.panel9.TabIndex = 60;
            // 
            // panel10
            // 
            this.panel10.Controls.Add(this.r10_2);
            this.panel10.Controls.Add(this.r10_1);
            this.panel10.Location = new System.Drawing.Point(879, 728);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(598, 110);
            this.panel10.TabIndex = 61;
            // 
            // Finish_btn
            // 
            this.Finish_btn.BackColor = System.Drawing.Color.Maroon;
            this.Finish_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Finish_btn.FlatAppearance.BorderSize = 0;
            this.Finish_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Finish_btn.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Finish_btn.ForeColor = System.Drawing.Color.White;
            this.Finish_btn.Location = new System.Drawing.Point(774, 869);
            this.Finish_btn.Name = "Finish_btn";
            this.Finish_btn.Size = new System.Drawing.Size(154, 36);
            this.Finish_btn.TabIndex = 62;
            this.Finish_btn.Text = "Finish";
            this.Finish_btn.UseVisualStyleBackColor = false;
            this.Finish_btn.Click += new System.EventHandler(this.Finish_btn_Click);
            // 
            // Exam
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(1489, 917);
            this.Controls.Add(this.Finish_btn);
            this.Controls.Add(this.panel10);
            this.Controls.Add(this.panel9);
            this.Controls.Add(this.panel8);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.q10);
            this.Controls.Add(this.q9);
            this.Controls.Add(this.q8);
            this.Controls.Add(this.q7);
            this.Controls.Add(this.q6);
            this.Controls.Add(this.q5);
            this.Controls.Add(this.q4);
            this.Controls.Add(this.q3);
            this.Controls.Add(this.q2);
            this.Controls.Add(this.q1);
            this.Name = "Exam";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Exam";
            this.Load += new System.EventHandler(this.Exam_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label q1;
        private RadioButton r1_1;
        private RadioButton r1_2;
        private RadioButton r1_3;
        private RadioButton r1_4;
        private RadioButton r2_4;
        private RadioButton r2_3;
        private RadioButton r2_2;
        private RadioButton r2_1;
        private Label q2;
        private RadioButton r4_4;
        private RadioButton r4_3;
        private RadioButton r4_2;
        private RadioButton r4_1;
        private Label q4;
        private RadioButton r3_4;
        private RadioButton r3_3;
        private RadioButton r3_2;
        private RadioButton r3_1;
        private Label q3;
        private RadioButton r6_4;
        private RadioButton r6_3;
        private RadioButton r6_2;
        private RadioButton r6_1;
        private Label q6;
        private RadioButton r5_4;
        private RadioButton r5_3;
        private RadioButton r5_2;
        private RadioButton r5_1;
        private Label q5;
        private RadioButton r10_2;
        private RadioButton r10_1;
        private Label q10;
        private RadioButton r8_4;
        private RadioButton r9_2;
        private RadioButton r9_1;
        private Label q9;
        private RadioButton r8_3;
        private RadioButton r8_2;
        private RadioButton r8_1;
        private Label q8;
        private RadioButton r7_4;
        private RadioButton r7_3;
        private RadioButton r7_2;
        private RadioButton r7_1;
        private Label q7;
        private PictureBox pictureBox1;
        private Label label1;
        private Panel panel1;
        private Panel panel2;
        private Panel panel3;
        private Panel panel4;
        private Panel panel5;
        private Panel panel6;
        private Panel panel7;
        private Panel panel8;
        private Panel panel9;
        private Panel panel10;
        private Button Finish_btn;
    }
}