using ExamnationSystem00.Models;


namespace ExamnationSystem00
{
    public partial class Login : Form
    {
        ExamDB ExamSys = new ExamDB();

        public Login()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void StBtn_Click(object sender, EventArgs e)
        {
          string email= Txtmail.Text;
          string password = TxtPass.Text;
            Students S =ExamSys.Students.FirstOrDefault(x=>x.Email==email && x.Password== password);
            
            if (S != null)
            {

                this.Visible = false;
                Student form2 = new Student(S.Ssn, S.FullName);
                form2.id = S.Ssn;
                form2.name = S.FullName;
                form2.ShowDialog();

            }

            else
                MessageBox.Show(" Email or password is not correct ");
        }

        private void TxtPass_TextChanged(object sender, EventArgs e)
        {

        }

        private void InsBtn_Click(object sender, EventArgs e)
        {
            string email = Txtmail.Text;
            string password = TxtPass.Text;
            Instructors I = ExamSys.Instructors.FirstOrDefault(x => x.Email == email && x.Password == password);
            if (I != null)
            {
                this.Visible = false;
                Instructor form3 = new Instructor(I.InsId,I.FullName);
                form3.ShowDialog();

            }
            else
                MessageBox.Show(" Email or password is not correct ");
        }
    }
}